﻿using BCP.Framework.Security;
using BCP.Sap.Models.Configuracion;
using BCP.Sap.Models.Swamp;
using System;
using System.Data;

namespace BCP.Sap.DataAccess
{
    public class DataAccessSwamp
    {
        private readonly string _servidor;
        private readonly string _baseDatos;
        private readonly string _usuario;
        private readonly string _password;
        private string _conexion;
        private string _nombreSP;

        public DataAccessSwamp(ConexionBaseDeDatos appConfig)
        {
            this._servidor = appConfig.servidorBd;
            this._baseDatos = appConfig.nombreBd;
            this._usuario = appConfig.usuarioBd;
            this._password = appConfig.passwordBd;
            this._password = SegCrypt.EncryptDecrypt(false, this._password);
            this._conexion = DataAccess.ConexionSQL(this._servidor, this._baseDatos, this._usuario, this._password);
        }

        public DataTable DatosBasicosCliente(string guid, string estado)
        {
            DataTable dataTable1 = new DataTable();
            this._nombreSP = "[SWAMP].[SWAMP_SESION_GET_BY_ID]";
            DataTable dataTable2;
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@SES_GUID", (object)guid, Direccion.Input);
                storeProcedure.AgregarParametro("@SES_ESTADO", (object)estado, Direccion.Input);
                dataTable2 = storeProcedure.RealizarConsulta(this._conexion);
                if (storeProcedure.Error != string.Empty)
                    throw new Exception("Procedimiento Almacenado: " + this._nombreSP + ", Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception ex)
            {
                throw;
            }
            return dataTable2;
        }

        public int DAInsertCuentaSwamp(RegistroSwampCuentaRequest request)
        {
            int response = 0;
            this._nombreSP = "[SWAMP].[SWAMP_CUENTA_INS]";
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@SES_GUID", request.data.ses_guid, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_ID", request.data.cta_id.ToString(), Direccion.InputOuput);
                storeProcedure.AgregarParametro("@CTA_APERTURA", request.data.cta_apertura, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_ORIGINAL", request.data.cta_original, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_COUNTFIRMANTES", request.data.cta_countfirmantes, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_COUNTPRODUCTOS", request.data.cta_countproductos, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_NUMFIRMANTES", request.data.cta_numfirmantes, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_APMATERNO", request.data.cta_appaterno, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_APPATERNO", request.data.cta_apmaterno, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CLIENTEDELBANCO", request.data.cta_clientedelbanco, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CODCIIU", request.data.cta_codciiu, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CODIGOSECTORISTA", request.data.cta_codigosectorista, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CODSUCURSALAGENCIA", request.usuario.sucursal + request.usuario.agencia, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CODTIPOBANCA", request.data.cta_codtipobanca, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CODTIPOTARJETACREDIMAS", request.data.cta_codtipotarjetacredimas, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CTAAPLAZOINFO", request.data.cta_ctaaplazoinfo, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_CTAEXCINFO", request.data.cta_ctaexcinfo, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_DIRECCION", request.data.cta_direccion, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_GREMIO", request.data.cta_gremio, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_IDC_N", request.cliente.idcNumero, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_IDC_S", request.cliente.idcTipo, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_IDC_T", request.cliente.idcExtension, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_LOCALIDADDESCRIPCION", request.data.cta_localidaddescripcion, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_MONTO", request.data.cta_monto, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_NOMBRES_RAZSOCIAL", request.data.cta_nombres_razsocial, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_NOMCOMERC_NOMCUENTA", request.data.cta_nomcomerc_nomcuenta, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_NUMEROCREDIMAS", request.data.cta_numerocredimas, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_SITUACIONTARJETADESCRIPCION", request.data.cta_situaciontarjetadescripcion, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_TARJETABANCAEXCLUSIVA", request.data.cta_tarjetabancaexclusiva, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_TELEFONO", request.data.cta_telefono, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_TIPOCUENTA", request.data.cta_tipocuenta, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_TIPOOPERACIONCREDIMAS", request.data.cta_tipooperacioncredimas, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_SUCAGE", request.usuario.sucursal + "-" + request.usuario.agencia, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_PRINT_ORI", false, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_PRINT_COP", false, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_USR_CREA", request.usuario.usuarioExtra, Direccion.Input);

                bool resultado=storeProcedure.EjecutarStoreProcedure(this._conexion);
                if (resultado)
                {
                    response = int.Parse(storeProcedure.getItem("@CTA_ID").ValorParametro.ToString());
                }                
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: SWAMP.SWAMP_CUENTA_INS, Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }
        public bool DAInsertCuentaProductoSwamp(RegistroSwampCuentaProductoRequest request)
        {
            bool response = false;
            this._nombreSP = "[SWAMP].[SWAMP_CUENTA_PRODUCTO_INS]";
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@SES_GUID", request.data.ses_guid, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_ID", request.data.cta_id, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_ID", request.data.pro_id, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_NUEVA", request.data.pro_nueva, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_CLAVE", request.data.pro_clave, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_CODMONEDA", request.data.pro_codmoneda, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_CODTIPOPRODUCTO", request.data.pro_codtipoproducto, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_MONTO", request.data.pro_monto, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_NUMEROCUENTA", request.data.pro_numerocuenta, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_SUBCODTIPOPRODUCTO", request.data.pro_subcodtipoproducto, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_TIPODPF", request.data.pro_tipodpf, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_TIPOPLAZO", request.data.pro_tipoplazo, Direccion.Input);
                storeProcedure.AgregarParametro("@PRO_USR_CREA", request.usuario, Direccion.Input);
                response = storeProcedure.EjecutarStoreProcedure(this._conexion);
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: SWAMP.SWAMP_CUENTA_PRODUCTO_INS, Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }
        public bool DAInsertCuentaFirmaSwamp(RegistroSwampCuentaFirmaRequest request)
        {
            bool response = false;
            this._nombreSP = "[SWAMP].[SWAMP_CUENTA_FIRMA_INS]";
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@SES_GUID", request.data.ses_guid, Direccion.Input);
                storeProcedure.AgregarParametro("@CTA_ID", request.data.cta_id, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_ID", request.data.fir_id, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_ACTUALIZADATOS", request.data.fir_actualizadatos, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_CLIENTENUEVO", request.data.fir_clientenuevo, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_APMATERNO", request.data.fir_apmaterno, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_APPATERNO", request.data.fir_appaterno, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_ESTADOCIVIL", request.data.fir_estadocivil, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_FECHANAC", request.data.fir_fechanac, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_IDC_N", request.cliente.idcNumero, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_IDC_S", request.cliente.idcExtension, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_IDC_T", request.cliente.idcTipo, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_NOMBRES_RAZSOCIAL", request.data.fir_nombres_razsocial, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_NUMEROCREDIMAS", request.data.fir_numerocredimas, Direccion.Input);
                storeProcedure.AgregarParametro("@FIR_USR_CREA", request.usuario, Direccion.Input);

                response = storeProcedure.EjecutarStoreProcedure(this._conexion);
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: SWAMP.SWAMP_CUENTA_INS, Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }
    }
}