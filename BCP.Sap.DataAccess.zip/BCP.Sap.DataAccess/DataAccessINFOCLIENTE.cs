﻿using BCP.Framework.Common;
using BCP.Framework.Security;
using BCP.Sap.Models.Comunes;
using BCP.Sap.Models.Configuracion;
using BCP.Sap.Models.INFOCLIENTE;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCP.Sap.DataAccess
{
    public class DataAccessINFOCLIENTE
    {
        private readonly string _servidor;
        private readonly string _baseDatos;
        private readonly string _usuario;
        private readonly string _password;
        private string _conexion;
        private string _nombreSP;

        public DataAccessINFOCLIENTE(ConexionBaseDeDatos appConfig)
        {
            this._servidor = appConfig.servidorBd;
            this._baseDatos = appConfig.nombreBd;
            this._usuario = appConfig.usuarioBd;
            this._password = appConfig.passwordBd;
            this._password = SegCrypt.EncryptDecrypt(false, this._password);
            this._conexion = DataAccess.ConexionSQL(this._servidor, this._baseDatos, this._usuario, this._password);
        }
        public bool InsertarCliente(INFOCLIENTEInsertRequest request, string canal)
        {
            bool response = false;
            this._nombreSP = "[InfoCli].[INFO_CLIENTE_SAPW_Insert]";
            string[] SPs = { this._nombreSP, "[InfoCli].[INFO_CLIENTE_TBLSAPW_Insert]" };
            bool[] verificar = new bool[SPs.Length];
            try
            {
                for (int i = 0; i < SPs.Length; i++)
                {
                    StoreProcedure storeProcedure = new StoreProcedure(SPs[i]);
                    storeProcedure.AgregarParametro("@strIdc", request.cliente.idcNumero, Direccion.Input);
                    storeProcedure.AgregarParametro("@strExt", request.cliente.idcExtension, Direccion.Input);//pareciera que siempre fuera0
                    storeProcedure.AgregarParametro("@strTipo", request.cliente.idcTipo, Direccion.Input);//
                    storeProcedure.AgregarParametro("@strPaterno", request.data.Paterno, Direccion.Input);
                    storeProcedure.AgregarParametro("@strMaterno", request.data.Materno, Direccion.Input);
                    storeProcedure.AgregarParametro("@strNombres", request.data.Nombres, Direccion.Input);
                    storeProcedure.AgregarParametro("@strFecNac", string.Join("",request.data.FechaNacimiento.Split('/')), Direccion.Input);//pareciera que siempre fuera0
                    storeProcedure.AgregarParametro("@strSexo", request.data.Sexo, Direccion.Input);//
                    storeProcedure.AgregarParametro("@strEstCivil", request.data.EstadoCivil, Direccion.Input);
                    storeProcedure.AgregarParametro("@strNacionalidad", request.data.Nacionalidad, Direccion.Input);

                    storeProcedure.AgregarParametro("@strCalle", request.data.strCalle, Direccion.Input);
                    storeProcedure.AgregarParametro("@strNumero", request.data.strNumeroDomicilio, Direccion.Input);//pareciera que siempre fuera0
                    storeProcedure.AgregarParametro("@strManzana", request.data.strManzana, Direccion.Input);//
                    storeProcedure.AgregarParametro("@strLote", request.data.strLote, Direccion.Input);
                    storeProcedure.AgregarParametro("@strDepartamento", request.data.strDepartamento, Direccion.Input);
                    storeProcedure.AgregarParametro("@strDepPiso", request.data.strDepPiso, Direccion.Input);
                    storeProcedure.AgregarParametro("@strUrbanizacionTipo", request.data.strUrbanizacionTipo, Direccion.Input);//pareciera que siempre fuera0               
                    storeProcedure.AgregarParametro("@strUrbanizacion", request.data.strUrbanizacion, Direccion.Input);//
                    storeProcedure.AgregarParametro("@strSectorTipo", request.data.strSectorTipo, Direccion.Input);
                    storeProcedure.AgregarParametro("@strSector", request.data.strSector, Direccion.Input);

                    storeProcedure.AgregarParametro("@strDireccion", request.data.Domicilio, Direccion.Input);
                    storeProcedure.AgregarParametro("@strLocalidad", request.data.Localidad, Direccion.Input);//pareciera que siempre fuera0
                    storeProcedure.AgregarParametro("@strTelefono", request.data.Telefono, Direccion.Input);//
                    storeProcedure.AgregarParametro("@strInstruccion", request.data.GradoInstruccion, Direccion.Input);
                    storeProcedure.AgregarParametro("@strProfesion", request.data.Profesion, Direccion.Input);
                    storeProcedure.AgregarParametro("@strSituacionLaboral", request.data.SituacionLaboral, Direccion.Input);
                    storeProcedure.AgregarParametro("@strCondVivienda", request.data.TipoVivienda, Direccion.Input);//pareciera que siempre fuera0               
                    storeProcedure.AgregarParametro("@strResidente", request.data.Residente.Equals("S") ? "1" : "0", Direccion.Input);//
                    storeProcedure.AgregarParametro("@strNegPropio", request.data.negocioPropio.Equals("S")?"1":"0", Direccion.Input);
                    storeProcedure.AgregarParametro("@strEmpresa", request.data.NombreEmpresa, Direccion.Input);
                    storeProcedure.AgregarParametro("@strNit", request.data.NIT, Direccion.Input);
                    storeProcedure.AgregarParametro("@strMail", request.data.Mail, Direccion.Input);//pareciera que siempre fuera0
                    storeProcedure.AgregarParametro("@strCelular", request.data.Celular, Direccion.Input);//
                    storeProcedure.AgregarParametro("@strCiiu", ManagerValidation.intSTR(request.data.CIIU), Direccion.Input);
                    storeProcedure.AgregarParametro("@strMagnitud", request.data.MagnitudEmpresa, Direccion.Input);
                    storeProcedure.AgregarParametro("@strCiiu2",ManagerValidation.intSTR(request.data.ciiu2), Direccion.Input);
                    storeProcedure.AgregarParametro("@vchCIC", request.data.CIC, Direccion.Input);
                    storeProcedure.AgregarParametro("@vchUSUARIO", request.usuario, Direccion.Input);
                    storeProcedure.AgregarParametro("@vchCANAL", canal, Direccion.Input);
                    verificar[i] = storeProcedure.EjecutarStoreProcedure(this._conexion);
                    if (storeProcedure.Error != String.Empty)
                        throw new Exception("Procedimiento Almacenado: " + SPs[i] + ", Descripcion:" + storeProcedure.Error.Trim());
                }
                response = !verificar.Contains(false);
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public DataTable DatosBasicosCliente(IdentificadorClienteNatural cliente)
        {
            DataTable response = new DataTable();
            this._nombreSP = "[InfoCli].[SAPPW_CLIENTE_ListByIdc]";
            try
            {
                string idc = cliente.idcNumero + cliente.idcTipo + cliente.idcExtension;
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@vchIDC", idc, Direccion.Input);
                response = storeProcedure.RealizarConsulta(this._conexion);
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: " + this._nombreSP + ", Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public DataTable DatosPersonalesCliente(int idCliente)
        {
            DataTable response = new DataTable();
            this._nombreSP = "[InfoCli].[SAPPW_DATOPERSONAL_ListById]";
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@CLIENTE_ID", idCliente, Direccion.Input);
                response = storeProcedure.RealizarConsulta(this._conexion);
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: " + this._nombreSP + ", Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public DataTable DatosLaboralesCliente(int idCliente)
        {
            DataTable response = new DataTable();
            this._nombreSP = "[InfoCli].[SWAMP_DATOLABORAL_ListById]";
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@CLIENTE_ID", idCliente, Direccion.Input);
                response = storeProcedure.RealizarConsulta(this._conexion);
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: " + this._nombreSP + ", Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }

        public DataTable DireccionCliente(int idCliente)
        {
            DataTable response = new DataTable();
            this._nombreSP = "[InfoCli].[SAPPW_DIRECCION_ListById]";
            try
            {
                StoreProcedure storeProcedure = new StoreProcedure(this._nombreSP);
                storeProcedure.AgregarParametro("@CLIENTE_ID", idCliente, Direccion.Input);
                response = storeProcedure.RealizarConsulta(this._conexion);
                if (storeProcedure.Error != String.Empty)
                    throw new Exception("Procedimiento Almacenado: " + this._nombreSP + ", Descripcion:" + storeProcedure.Error.Trim());
            }
            catch (Exception)
            {
                throw;
            }
            return response;
        }
    }
}
